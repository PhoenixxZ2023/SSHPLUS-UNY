# SCOTT PRO ⚡
# @SCOTTSSH

```
apt install wget -y; bash <(wget -qO- https://ssh.pw5g.com.br/ssh-plus)

```